glslDevil - A Hardware-Aware GLSL Debugger
==========================================

Version 1.1.5
Webpage: http://www.vis.uni-stuttgart.de/glsldevil/
Contact: glsldevil@vis.uni-stuttgart.de

Authors:
 Thomas Klein
 Magnus Strengert
 Guido Reina
 Christoph Mueller

